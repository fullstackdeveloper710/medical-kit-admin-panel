// pages/Users.js

import React from "react";

function Users() {
  return (
    <div>
      <h2>Users Page</h2>
      <p>List of users will be displayed here.</p>
    </div>
  );
}

export default Users;
